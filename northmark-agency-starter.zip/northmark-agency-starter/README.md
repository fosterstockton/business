# Northmark agency website starter

This is an initial Astro starter for the Northmark public-facing agency website.

## Important before publishing
- Northmark is a working name, not a trademark/domain clearance.
- Replace `YOUR-DOMAIN.example` in `astro.config.mjs`.
- Replace the placeholder email address in the footer and contact page.
- The contact form currently uses a `mailto:` demo action. It is NOT a reliable production lead form. Connect a form provider or secure backend and test it before launch.
- Pricing is draft positioning and should be confirmed before accepting customers.
- Demo portfolio entries are explicitly labelled as concepts. Do not represent them as client work.

## Run locally
```bash
npm install
npm run dev
```

## Production build
```bash
npm run build
npm run preview
```

## Suggested next steps
1. Open this folder in Claude Code.
2. Ask Claude to audit the project, improve visual polish, check accessibility and responsive layouts, and fix any build errors.
3. Replace demo portfolio concepts with original sample sites.
4. Connect a real contact form.
5. Deploy to Cloudflare Pages after the domain and brand checks.

Astro and Cloudflare deployment documentation:
- https://docs.astro.build/
- https://developers.cloudflare.com/pages/framework-guides/deploy-an-astro-site/
