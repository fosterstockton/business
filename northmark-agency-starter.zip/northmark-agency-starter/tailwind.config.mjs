/** @type {import('tailwindcss').Config} */
export default {
  content: ["./src/**/*.{astro,html,js,jsx,md,mdx,svelte,ts,tsx,vue}"],
  theme: {
    extend: {
      colors: {
        ink: "#111C2B",
        navy: "#17263A",
        muted: "#64748B",
        paper: "#F7F8FA",
        line: "#E5E9EF",
        accent: "#557A9E"
      },
      fontFamily: {
        sans: ["Inter", "ui-sans-serif", "system-ui", "sans-serif"]
      },
      boxShadow: {
        soft: "0 18px 50px rgba(17, 28, 43, .08)"
      }
    }
  },
  plugins: []
};